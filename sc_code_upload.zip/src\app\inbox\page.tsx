// /src/app/inbox/page.tsx
import { redirect } from "next/navigation";
export default function InboxRedirect() {
  redirect("/pro/mypage");
}