// src/data/experts.ts
export type Gender = "male" | "female";

/**
 * Expert データ型
 * - location（所在地）を追加
 * - boardMembers: 自分のボードに載せている相手
 * - joinedBoards: 参加しているボード（オーナーID）
 */
export type Expert = {
  id: string;
  name: string;
  license?: string; // 無資格も許容
  title: string;
  tags: string[];
  price: string;
  online: boolean;
  rating: number;
  reviews: number;
  gender: Gender;
  bio: string;

  location: string;         // 追加: 所在地
  boardMembers?: string[];  // 追加: 自分のボードに載せている相手ID
  joinedBoards?: string[];  // 追加: 参加しているボード（オーナーID）
};

export const EXPERTS: Expert[] = [
  {
    id: "1",
    name: "山田 太郎",
    license: "税理士",
    title: "法人税・決算相談",
    tags: ["法人税", "節税", "中小企業"],
    price: "30分/¥5,000",
    online: true,
    rating: 4.8,
    reviews: 132,
    gender: "male",
    bio: "中小企業向けの法人税務を中心に活動。節税や資金繰り改善のアドバイスが得意です。",
    location: "東京都 千代田区",
    boardMembers: ["11"],
  },
  {
    id: "2",
    name: "佐藤 花子",
    license: "社会保険労務士",
    title: "労務管理・就業規則",
    tags: ["労基法", "就業規則", "助成金"],
    price: "30分/¥4,000",
    online: false,
    rating: 4.6,
    reviews: 89,
    gender: "female",
    bio: "就業規則の整備や労務トラブルの予防に注力。助成金申請のサポート経験も豊富です。",
    location: "大阪府 大阪市",
    joinedBoards: ["1"],
  },
  {
    id: "3",
    name: "鈴木 健一",
    license: "司法書士",
    title: "登記・相続相談",
    tags: ["会社設立", "相続", "不動産登記"],
    price: "20分/¥3,000",
    online: true,
    rating: 4.7,
    reviews: 76,
    gender: "male",
    bio: "会社設立や相続登記を中心にサポート。初めての手続きでも分かりやすく説明します。",
    location: "愛知県 名古屋市",
  },
  {
    id: "4",
    name: "高橋 美咲",
    license: "行政書士",
    title: "許認可・契約書相談",
    tags: ["建設業許可", "契約書レビュー"],
    price: "30分/¥3,500",
    online: true,
    rating: 4.5,
    reviews: 54,
    gender: "female",
    bio: "許認可申請や各種契約書の作成・チェックを迅速に対応します。",
    location: "福岡県 福岡市",
  },
  {
    id: "5",
    name: "田中 大輔",
    license: "弁護士",
    title: "企業法務・労務トラブル",
    tags: ["労働問題", "顧問契約"],
    price: "30分/¥8,000",
    online: false,
    rating: 4.9,
    reviews: 210,
    gender: "male",
    bio: "企業法務全般を担当。労務問題の初動対応・交渉が強みです。",
    location: "神奈川県 横浜市",
  },
  {
    id: "6",
    name: "松本 真由美",
    license: "公認会計士",
    title: "監査・内部統制相談",
    tags: ["監査対応", "上場準備"],
    price: "40分/¥10,000",
    online: false,
    rating: 4.7,
    reviews: 65,
    gender: "female",
    bio: "IPO準備・内部統制の整備運用を支援。監査対応の実務経験が豊富です。",
    location: "京都府 京都市",
    boardMembers: ["1"],
  },
  {
    id: "7",
    name: "伊藤 翔",
    license: "弁理士",
    title: "特許・商標相談",
    tags: ["特許申請", "商標調査"],
    price: "25分/¥6,000",
    online: true,
    rating: 4.4,
    reviews: 33,
    gender: "male",
    bio: "スタートアップの知財戦略を支援。短時間での方針整理が好評です。",
    location: "北海道 札幌市",
  },
  {
    id: "8",
    name: "中村 彩",
    license: "税理士",
    title: "相続税・贈与税相談",
    tags: ["相続税", "贈与税", "資産承継"],
    price: "30分/¥5,500",
    online: true,
    rating: 4.8,
    reviews: 97,
    gender: "female",
    bio: "資産承継や事業承継の設計を中心に、わかりやすさを大切にしています。",
    location: "兵庫県 神戸市",
  },
  {
    id: "9",
    name: "小林 一郎",
    license: "社会保険労務士",
    title: "給与計算・年末調整",
    tags: ["給与計算", "年末調整"],
    price: "20分/¥3,000",
    online: false,
    rating: 4.3,
    reviews: 41,
    gender: "male",
    bio: "給与計算や年末調整の実務経験豊富。効率的で正確な処理を心がけています。",
    location: "千葉県 千葉市",
  },
  {
    id: "10",
    name: "斎藤 真央",
    license: undefined, // 葬儀屋 → 無資格
    title: "葬儀・終活相談",
    tags: ["葬儀プラン", "終活", "供養"],
    price: "30分/¥2,000",
    online: true,
    rating: 4.2,
    reviews: 22,
    gender: "female",
    bio: "地域密着で葬儀や終活相談をサポート。安心してご相談いただけます。",
    location: "埼玉県 さいたま市",
  },
  {
    id: "11",
    name: "大森 健太",
    license: "ファイナンシャルプランナー",
    title: "ライフプラン・資産運用",
    tags: ["資産運用", "保険", "家計管理"],
    price: "30分/¥4,500",
    online: true,
    rating: 4.6,
    reviews: 58,
    gender: "male",
    bio: "将来設計や資産運用をわかりやすく提案。保険や投資もトータルに相談可能です。",
    location: "東京都 渋谷区",
    joinedBoards: ["1"],
  },
];
